package graph;

import java.util.Objects;

public class Noeud {
    private String nom;
    private String descr;
    private boolean visit;

    public Noeud(String nom, String descr) {
        this.nom = nom;
        this.descr = descr;
    }

    public Noeud(String nom) {
        this.nom = nom;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Noeud noeud = (Noeud) o;
        return Objects.equals(nom, noeud.nom);
    }

    @Override
    public int hashCode() {
        return Objects.hash(nom);
    }

    @Override
    public String toString() {
        return nom + " ";
    }

    public boolean isVisit() {
        return visit;
    }

    public void setVisit(boolean visit) {
        this.visit = visit;
    }
}