package arbre;

/**
 * Structures de donn�es : Les Arbres n-aires
 *    Version : fils impl�ment�s dans une liste des fr�res
 * @author Ch. Stettler - HEG-Gen�ve
 */
public class ArbreNrList {

	private Noeud racine;

	public ArbreNrList() { racine=null; }

	static class Noeud {
		private Noeud filsAine;
		private int contenu;
		private Noeud frere;

		public Noeud(int contenu) { this(null,contenu, null); }
		public Noeud(Noeud filsAine, int contenu, Noeud frere) { this.filsAine=filsAine; this.contenu=contenu; this.frere=frere; }

		public  String toString() { return contenu+"\n"+ (filsAine!=null ? filsAine.toString("\t") : ""); }
		private String toString(String s) {
			if (filsAine != null) return (s+contenu+"\n"+filsAine.toString(s+"\t") + (frere==null ? "" : frere.toString(s)));
			return(s+contenu+"\n"+ (frere==null ? "" : frere.toString(s)));
		}
	}

	public Noeud inserer(int x, Noeud pere) {
		Noeud n = new Noeud(x); 
		if (pere == null) { return racine = n; }
		if (pere.filsAine == null) { return pere.filsAine = n; }
		Noeud fils = pere.filsAine; while (fils.frere != null) { fils = fils.frere; }
		return fils.frere = n;
	}

	public  void parcoursPrefixe() { parcoursPrefixe(racine); }
	private void parcoursPrefixe(Noeud n) {
		if (n == null) { return; }
		System.out.print(n.contenu + " ");
		parcoursPrefixe(n.filsAine);
		parcoursPrefixe(n.frere);
	}
	public  void parcoursPostfixe() { parcoursPostfixe(racine); }
	private void parcoursPostfixe(Noeud n) {
		if (n == null) { return; }
		parcoursPostfixe(n.filsAine);
		System.out.print(n.contenu + " ");
		parcoursPostfixe(n.frere);
	}

	public  Noeud chercher(int x) { return chercher(x, racine); }
	private Noeud chercher(int x, Noeud n) {
		if (n == null || x == n.contenu) { return n; }
		Noeud f = chercher(x, n.filsAine);
		if (f != null) { return f; }
		return chercher(x, n.frere);
	}

	public  boolean supprimer(int x) { return supprimer(x, racine); }
	private boolean supprimer(int x, Noeud n) {
		return false;
	}

	public  int taille() { return taille(racine); }
	private int taille(Noeud n) {
		if (n == null) { return 0; }
		return 1 + taille(n.filsAine) + taille(n.frere);
	}
	
	public String toString() { return racine.toString(); }


	public static void main (String[] args) {
		ArbreNrList a = new ArbreNrList();
		a.inserer(0, null); a.inserer(1, a.chercher(0)); a.inserer(2, a.chercher(0)); a.inserer(3, a.chercher(0)); a.inserer(4, a.chercher(0));
		a.inserer(11, a.chercher(1)); a.inserer(12, a.chercher(1)); a.inserer(13, a.chercher(1)); a.inserer(14, a.chercher(1)); 
		a.inserer(121, a.chercher(12)); a.inserer(122, a.chercher(12)); a.inserer(123, a.chercher(12)); 
		a.inserer(1221, a.chercher(122)); 
		a.inserer(31, a.chercher(3)); a.inserer(32, a.chercher(3)); 
		a.inserer(311, a.chercher(31)); a.inserer(312, a.chercher(31)); a.inserer(313, a.chercher(31)); 
		a.inserer(41, a.chercher(4));

		a.parcoursPrefixe();  System.out.println();
		a.parcoursPostfixe(); System.out.println();

		System.out.println("Chercher 12: \n" + a.chercher(12));
		System.out.println("Taille: " + a.taille());

		System.out.println("Supprimer 122: " + a.supprimer(122));
		System.out.println(a);
	}
}