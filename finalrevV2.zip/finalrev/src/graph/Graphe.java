package graph;public interface graphe {
    void addRelation(Noeud source, Noeud dest);

    boolean existeRelation(Noeud source, Noeud dest);

    // !! Il faut rajouter un test pour savoir si un Noeud a d�j� �t� visit� !!
    void parcourirProfondeurVersionDeBase(Noeud noeud);

    abstract boolean existeChemin(Noeud source, Noeud dest);

    default boolean parcourirProfondeurUntilDest(Noeud noeud, Noeud dest) {
//      if (noeud.isVisit()) { return; }
//      noeud.setVisit(true);
        if (lstDesNoeudsDejaVisites.contains(noeud)) { return false; }
        lstDesNoeudsDejaVisites.add(noeud);

        if (noeud.equals(dest)) { return true; }

        for (Noeud rel : lstNoeuds.get(noeud)) {
            if (parcourirProfondeurUntilDest(rel, dest)) { return true; }
        }
        return false;
    }

    abstract void parcourirProfondeur(Noeud noeud);
}
