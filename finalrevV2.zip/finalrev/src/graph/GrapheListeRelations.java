package graph;

import java.util.*;

public class GrapheListeRelations implements graphe {
    private Map<Noeud, Set<Noeud>> lstNoeuds;
    private List<Noeud> lstDesNoeudsDejaVisites = new ArrayList<>();

    public GrapheListeRelations() {
        lstNoeuds = new HashMap<>();
    }

    @Override
    public void addRelation(Noeud source, Noeud dest) {
        Set<Noeud> relations = lstNoeuds.get(source);
        if (relations == null) {
            relations = new HashSet<>();
        }
        relations.add(dest);
        lstNoeuds.put(source, relations);

        relations = lstNoeuds.get(dest);
        if (relations == null) {
            relations = new HashSet<>();
        }
        relations.add(source);
        lstNoeuds.put(dest, relations);
    }

    @Override
    public boolean existeRelation(Noeud source, Noeud dest) {
        return lstNoeuds.get(source).contains(dest);
    }

    @Override
    // !! Il faut rajouter un test pour savoir si un Noeud a déjà été visité !!
    public void parcourirProfondeurVersionDeBase(Noeud noeud) {
        System.out.print(noeud);
        for (Noeud rel : lstNoeuds.get(noeud)) {
            parcourirProfondeur(rel);
        }
    }

    @Override
    public boolean existeChemin(Noeud source, Noeud dest) {
        return parcourirProfondeurUntilDest(source, dest);
    }

    @Override
    public boolean parcourirProfondeurUntilDest(Noeud noeud, Noeud dest) {
        //      if (noeud.isVisit()) { return; }
//      noeud.setVisit(true);
        if (lstDesNoeudsDejaVisites.contains(noeud)) { return false; }
        lstDesNoeudsDejaVisites.add(noeud);

        if (noeud.equals(dest)) { return true; }

        for (Noeud rel : lstNoeuds.get(noeud)) {
            if (parcourirProfondeurUntilDest(rel, dest)) { return true; }
        }
        return false;
    }

    @Override
    public void parcourirProfondeur(Noeud noeud) {
        // Différentes versions de gestion des noeuds visités :

        // a) rajouter un attribut "visit" dans la classe Noeud
        if (noeud.isVisit()) {
            return;
        }
        noeud.setVisit(true);

        // b) conserver une liste des noeuds visités
        if (lstDesNoeudsDejaVisites.contains(noeud)) {
            return;
        }
        lstDesNoeudsDejaVisites.add(noeud);

        // c) créer une nouvelle classe qui serait un wrapper de Noeud, et qui contient un attribut "visit"
        // d) créer une nouvelle classe qui implémenterait un interface Visitable

        System.out.print(noeud);
        for (Noeud rel : lstNoeuds.get(noeud)) {
            parcourirProfondeur(rel);
        }
    }
    // !! Il faut également penser à réinitialiser les noeuds visités !!
    // !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
}