package graph;

import graph.GrapheListeRelations;
import graph.graphe;

public class ExGraphe {
    public static void main(String[] args) {
        graphe gr = new GrapheListeRelations();

        Noeud a = new Noeud("A", "Description du noeud A");
        Noeud b = new Noeud("B", "Description du noeud B");
        Noeud c = new Noeud("C", "Description du noeud C");
        Noeud d = new Noeud("D", "Description du noeud D");
        Noeud e = new Noeud("E", "Description du noeud E");
        Noeud f = new Noeud("F", "Description du noeud F");
        Noeud g = new Noeud("G", "Description du noeud G");
        Noeud h = new Noeud("H", "Description du noeud H");

        gr.addRelation(a,b); gr.addRelation(b,c); gr.addRelation(a,d); gr.addRelation(b,d);
        gr.addRelation(b,e); gr.addRelation(d,e); gr.addRelation(f,g); gr.addRelation(g,h);

        System.out.println("a->b : " + gr.existeRelation(a,b));
        System.out.println("b->c : " + gr.existeRelation(b,c));
        System.out.println("a->e : " + gr.existeRelation(a,e));
        System.out.println("b->a : " + gr.existeRelation(b,a));

        System.out.println("Chemin a-e : " + gr.existeChemin(a, e));
        System.out.println("Chemin a-h : " + gr.existeChemin(a, h));
    }
}